# Halcon Alarm — Clon estático (HTML & CSS)

Este clon está implementado solo con HTML y CSS (sin JavaScript) por defecto, usando un checkbox CSS-only para el estado de la alarma.

Archivos principales:

- `index.html` — Interfaz principal responsive.
- `style.css` — Estilos del proyecto (incluye comportamiento del toggle con pseudo-elementos).

Cómo ver en local:

PowerShell (en la carpeta del proyecto):

```powershell
python -m http.server 8000
# Abrir http://localhost:8000 en el navegador
```

Notas:
- Si quieres que reemplace iconos por SVG exactos o use la tipografía exacta del Figma, comparte los assets o acceso público al archivo Figma.
- Puedo añadir JavaScript si prefieres comportamiento adicional (persistencia, peticiones a API, animaciones complejas).
